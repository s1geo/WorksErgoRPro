from vcCommand import *
#-------------------------------------------------------------------------------

app = getApplication()
selectionManager = app.SelectionManager
netCommand = app.findCommand('netCommand')

def OnStart(): # Command starts here, all it does is display Action Panel. Up to User to then select 'Select Holes' button
  msg = '''Before(and After) using this command:\n  1) Goto [Controller Map] tab\n  2) Right Mouse Click Controller Icon [KSS 8.3]\n  3) Select [Manage Robot Variables]\n  4) Click [Clean Up] button in Variables list'''
  print msg

  """
  msg += '''Do you wish to continue?'''
  if app.messageBox( msg,"Unique Names",VC_MESSAGE_TYPE_QUESTION,VC_MESSAGE_BUTTONS_OKCANCEL) == VC_MESSAGE_RESULT_CANCEL:
    return
  """
  routine = app.TeachContext.ActiveRoutine # How to get the active Routine
  if not routine: # deal with special case of nothing selected, either can abort or use the Main routine
    robot = app.TeachContext.ActiveRobot # How to get the active Robot
    if not robot: return
    executor = robot.findBehavioursByType(VC_ROBOTEXECUTOR)[0]
    program = executor.Program
  else: # the easy way
    program = routine.Program
  #endif

  routines = program.Routines
  routines.insert(0,program.MainRoutine)

  for r in routines:
    doScope( r )

  print 'UNIQUENAME points converted'

  app.render()

def doScope(scope):
  for s in scope.Statements:
    if s.Type == VC_STATEMENT_IF:
      doScope(s.ThenScope)
      doScope(s.ElseScope)
    elif s.Type == VC_STATEMENT_WHILE:
      doScope(s.Scope)
    elif s.Type == VC_STATEMENT_CUSTOM:
      try:
        pos = s.Positions[0]
        pos.Name = pos.Name.replace('__UNIQUENAME__','')
      except:
        pass
    #endif
  #endfor

addState( None )
