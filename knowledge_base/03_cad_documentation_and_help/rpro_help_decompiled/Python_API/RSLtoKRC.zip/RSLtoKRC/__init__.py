from vcApplication import *

def OnStart():
  localize = findCommand('netCommand') 

  cmduri = getApplicationPath() + 'rsl2krc.py'
  cmd = loadCommand('rsl2krc', cmduri)
  addMenuItem('VcTabTeach/Convert', 'Convert RSL to KRC', -1, cmd.Name, 'Converts VC RSL syntax to KUKA KRC syntax', 'rgImportGeneral' )

  cmduri = getApplicationPath() + 'uniquenames.py'
  cmd = loadCommand('krcuniquenames', cmduri)
  addMenuItem('VcTabTeach/Convert', 'Remove Unique Names Label', -1, cmd.Name, 'Fixes the Unique Names issue with Position Statements', 'rgImportGeneral' )

  cmduri = getApplicationPath() + 'krc2rsl.py'
  cmd = loadCommand('krc2rsl', cmduri)
  addMenuItem('VcTabTeach/Convert', 'Convert KRC to RSL', -1, cmd.Name, 'Converts KUKA KRC syntax to VC RSL syntax', 'rgImportGeneral' )

