from vcCommand import *
#-------------------------------------------------------------------------------

app = getApplication()
selectionManager = app.SelectionManager
netCommand = app.findCommand('netCommand')

def OnStart(): # Command starts here, all it does is display Action Panel. Up to User to then select 'Select Holes' button
  global controller

  routine = app.TeachContext.ActiveRoutine # How to get the active Routine
  if not routine: # deal with special case of nothing selected, either can abort or use the Main routine
    robot = app.TeachContext.ActiveRobot # How to get the active Robot
    if not robot: return
    executor = robot.findBehavioursByType(VC_ROBOTEXECUTOR)[0]
    program = executor.Program
  else: # the easy way
    program = routine.Program
    executor = program.Executor
  #endif
  controller = executor.Controller

  routines = program.Routines
  routines.insert(0,program.MainRoutine)

  for r in routines:
    doScope( r )

  app.render()

def doScope(scope):
  for s in scope.Statements:
    if s.Type == VC_STATEMENT_IF:
      doScope(s.ThenScope)
      doScope(s.ElseScope)
    elif s.Type == VC_STATEMENT_WHILE:
      doScope(s.Scope)
    else:
      convertStatement(s)

#-------------------------------------------------------------------------------
# Dictionary which maps VC statements to KRL equivalence
KRLStatements = {
  VC_STATEMENT_COMMENT:'KukaBe.Applications.JobMap.JobMapCommands.CommentStatement',
  VC_STATEMENT_WAITBIN:'KukaBe.Applications.JobMap.JobMapCommands.GetInputStatement',
  VC_STATEMENT_LINMOTION:'KukaBe.Applications.JobMap.JobMapCommands.LinStatement',
  VC_STATEMENT_PTPMOTION:'KukaBe.Applications.JobMap.JobMapCommands.PtpStatement',
  VC_STATEMENT_SETBIN:'KukaBe.Applications.JobMap.JobMapCommands.SetOutputStatement',
  VC_STATEMENT_DELAY:'KukaBe.Applications.JobMap.JobMapCommands.WaitStatement'
  }

def convertStatement( statement ):

  statementType = KRLStatements.get(statement.Type, None) # dictionary lookup to map desired VC statement to the KRL equivalent in dotNET.
  if not statementType: return

  selectionManager.setSelection( statement ) # This trick is needed so dotNET knows where to add the statement
  netCommand.execute('LoadStatementAction', statementType, False ) # False flag operation means AFTER active statement
  activeStatement = selectionManager.getSelection(VC_SELECTION_STATEMENT)[0] # how we get the new statement created in dotNET

  if statement.Type == VC_STATEMENT_DELAY:
    activeStatement.Time = statement.Delay

  elif statement.Type == VC_STATEMENT_COMMENT:
    activeStatement.sParameter1 = statement.Comment

  elif statement.Type == VC_STATEMENT_SETBIN:
    activeStatement.getProperty('Index').Value = statement.OutputPort
    if statement.OutputValue: state = 'TRUE'
    else: state = 'FALSE'
    activeStatement.State = state

  elif statement.Type == VC_STATEMENT_WAITBIN:
    activeStatement.iParameter1  = statement.InputPort
    if statement.InputValue: state = 'TRUE'
    else: state = 'FALSE'
    activeStatement.stParameter1 = state

  elif statement.Type in [VC_STATEMENT_PTPMOTION,VC_STATEMENT_LINMOTION]:
    rslPos = statement.Positions[0]
    name = rslPos.Name

    activeStatement.Base  = statement.Base
    activeStatement.Tool  = statement.Tool
    activeStatement.ExternalTCP  = statement.ExternalTCP 
    if statement.AccuracyValue > 0: CONT = 'CONT'
    else: CONT = ''
    activeStatement.Continuous = CONT
    activeStatement.ApoDist = statement.AccuracyValue

    if statement.Type == VC_STATEMENT_PTPMOTION:
      activeStatement.VelPtp  = statement.JointSpeed
      activeStatement.Acc  = statement.JointForce
      activeStatement.PData_Name = 'PDAT%s'%name

    elif statement.Type == VC_STATEMENT_LINMOTION:
      activeStatement.VelAbs  = statement.MaxSpeed
      activeStatement.AccPerc = statement.Acceleration/controller.MaxCartesianAccel
      activeStatement.LData_Name = 'CPDAT%s'%name
    #endif

    krcPos = activeStatement.Positions[0]
    krcPos.setJoints(rslPos.JointValues) 
    krcPos.Configuration = rslPos.Configuration
    krcPos.PositionInReference = rslPos.PositionInReference
    krcPos.Name = name + '__UNIQUENAME__'
    krcPos.Name = name 

  #endif

  scope = statement.ParentScope
  scope.deleteStatement(statement)

addState( None )
