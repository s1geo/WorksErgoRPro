from vcCommand import *
#-------------------------------------------------------------------------------

app = getApplication()
selectionManager = app.SelectionManager
if 'KUKA' in app.ProductName:
  KUKASIM = True
else:
  KUKASIM = False

def OnStart(): # Command starts here, all it does is display Action Panel. Up to User to then select 'Select Holes' button
  global controller

  routine = app.TeachContext.ActiveRoutine # How to get the active Routine
  if not routine: # deal with special case of nothing selected, either can abort or use the Main routine
    robot = app.TeachContext.ActiveRobot # How to get the active Robot
    if not robot: return
    executor = robot.findBehavioursByType(VC_ROBOTEXECUTOR)[0]
    program = executor.Program
  else: # the easy way
    program = routine.Program
    executor = program.Executor
  #endif
  controller = executor.Controller

  routines = program.Routines
  routines.insert(0,program.MainRoutine)

  for r in routines:
    doScope( r )

  app.render()

def doScope(scope):
  for i,s in enumerate(scope.Statements):
    if s.Type == VC_STATEMENT_IF:
      doScope(s.ThenScope)
      doScope(s.ElseScope)
    elif s.Type == VC_STATEMENT_WHILE:
      doScope(s.Scope)
    else:
      convertStatement(i,s)

#-------------------------------------------------------------------------------

def getBase( statement ):
  if KUKASIM: return statement.Base

  for line in statement.Data.split('\n'):
    if '<base name="' in line: 
      bnum = int(line.split(' index="',1)[1].split('"',1)[0])
      if bnum < 0: return None
      return controller.Bases[bnum]

def getTool( statement ):
  if KUKASIM: return statement.Tool

  for line in statement.Data.split('\n'):
    if '<tool name="' in line: 
      bnum = int(line.split(' index="',1)[1].split('"',1)[0])
      if bnum < 0: return None
      return controller.Tools[bnum]

def getValue( statement, name ):
  if KUKASIM: return statement.getProperty(name).Value

  for line in statement.Data.split('\n'):
    if '<property name="%s"'%name in line: 
      sValue = line.split(' value="',1)[1].split('"',1)[0]
      if 'type="System.Double"' in line: return float(sValue)
      if 'type="System.Int32"' in line: return int(sValue)
      if 'type="System.Boolean"' in line: return bool(sValue)
      return sValue

def convertStatement( sIndex, statement ):

  if KUKASIM:
    if not statement.Type == VC_STATEMENT_CUSTOM: return
    jmc = statement.getProperty('JMC::Key').Value
    if   'GOTOPT' in jmc: TypeString = 'PtpStatement'
    elif 'GOTOLI' in jmc: TypeString = 'LinStatement'
    elif 'WAIT2_' in jmc: TypeString = 'WaitStatement'
    elif 'MESSAG' in jmc: TypeString = 'CommentStatement'
    elif 'INPUT_' in jmc: TypeString = 'GetInputStatement'
    elif 'OUTPT2' in jmc: TypeString = 'SetOutputStatement'
    else: return
  else:
    if not statement.getProperty('TypeString'): return
    TypeString = statement.TypeString

  scope = statement.ParentScope

  if TypeString == 'WaitStatement':
    activeStatement = scope.addStatement( VC_STATEMENT_DELAY, sIndex )
    activeStatement.Delay = getValue(statement, 'Time' )

  elif TypeString == "CommentStatement":
    activeStatement = scope.addStatement( VC_STATEMENT_COMMENT, sIndex )
    activeStatement.Comment = getValue(statement, 'sParameter1' )

  elif TypeString == "SetOutputStatement":
    activeStatement = scope.addStatement( VC_STATEMENT_SETBIN, sIndex )
    activeStatement.OutputPort = getValue(statement, 'Index' )
    if getValue(statement, 'State' ) == 'TRUE': state = True
    else: state = False
    activeStatement.OutputValue = state

  elif TypeString == "GetInputStatement":
    activeStatement = scope.addStatement( VC_STATEMENT_WAITBIN, sIndex )
    activeStatement.InputPort = getValue(statement, 'iParameter1' )
    if getValue(statement, 'stParameter1' ) == 'TRUE': state = True
    else: state = False
    activeStatement.InputValue = state

  elif TypeString in ['PtpStatement','LinStatement']:
    if TypeString == 'PtpStatement':
      activeStatement = scope.addStatement( VC_STATEMENT_PTPMOTION, sIndex )
    elif TypeString == 'LinStatement':
      activeStatement = scope.addStatement( VC_STATEMENT_LINMOTION, sIndex )
    else:
      return

    activeStatement.Base  = getBase(statement)
    activeStatement.Tool  = getTool(statement)
    activeStatement.ExternalTCP  = getValue( statement, 'ExternalTCP' )

    if getValue(statement,'Continuous') == 'CONT':
      activeStatement.AccuracyValue = getValue(statement,'ApoDist')
    else:
      activeStatement.AccuracyValue = 0.0

    if activeStatement.Type == VC_STATEMENT_PTPMOTION:
      activeStatement.JointSpeed = getValue(statement,'VelPtp')
      activeStatement.JointForce = getValue(statement,'Acc')

    elif activeStatement.Type == VC_STATEMENT_LINMOTION:
      activeStatement.MaxSpeed = getValue(statement,'VelAbs')
      activeStatement.Acceleration = getValue(statement,'AccPerc')*controller.MaxCartesianAccel
    #endif

    krcPos = statement.Positions[0]
    rslPos = activeStatement.Positions[0]
    rslPos.setJoints(krcPos.JointValues) 
    rslPos.Configuration = krcPos.Configuration
    rslPos.PositionInReference = krcPos.PositionInReference
    rslPos.Name = krcPos.Name

  #endif

  scope.deleteStatement(statement)

addState( None )
