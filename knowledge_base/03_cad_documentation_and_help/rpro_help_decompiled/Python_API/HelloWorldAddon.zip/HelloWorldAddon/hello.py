from vcCommand import * 

cmd = getCommand()
message = cmd.createProperty(VC_STRING, "Message")
end_button = cmd.createProperty(VC_BUTTON, "Respond")
   
def first_state():
  executeInActionPanel()
  
  app = cmd.Application
  if app.CurrentContext.Id == "Drawing":
    print "Hello Drawing World"
  else:
    print "How is it going?"
  
addState(first_state)

def OnRespond(args):
  print cmd.Message

end_button.OnChanged = OnRespond