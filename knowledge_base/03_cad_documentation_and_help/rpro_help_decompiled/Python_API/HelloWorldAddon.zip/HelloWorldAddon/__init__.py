from vcApplication import *

def OnAppInitialized():
  cmduri = getApplicationPath() + "hello.py" 
  cmd = loadCommand("hello",cmduri)
  
  localize = findCommand("netCommand")
  localize.execute("SetLocalizationCommand", "English", "Python", "hello", "Text", "Hello")
  localize.execute("SetLocalizationCommand", "English", "Python", "hello", "Tooltip", "Print Hello World")
  localize.execute("SetLocalizationCommand", "English", "Python", "hello", "Icon", "HelloWorld.svg")
  localize.execute("SetLocalizationCommand", "German", "Python", "hello", "Text", "Hallo")
  localize.execute("SetLocalizationCommand", "German", "Python", "hello", "Text", "Print Hallo Welt")
  localize.execute("SetLocalizationCommand", "German", "Python", "hello", "Icon", "HelloWorld.svg")
  
  addMenuItem(VC_MENU_HOME, "hello", -1, "hello")
  addMenuItem(VC_MENU_DRAWING, "hello", -1, "hello")