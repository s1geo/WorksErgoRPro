from vcApplication import *

def OnStart():
    if findCommand("__MyProcessButton__") == None:
        loadCommand("__MyProcessButton__", getApplicationPath() + '__MyProcessButton__.py')

    addMenuItem("VcProgramStatements/ProgramStatements/Movement", "TestProcess", -1, '__MyProcessButton__', 'CreateCalltStatementTooltipContentTextId', 'Statement/sCallSequence')

    print "Adding custom process button!"


