from vcApplication import *
from vcCommand import *
from vcHelpers.Selection import *
from vcHelpers.Application import *
import vcMatrix

app = getApplication()
cmd = getCommand()
comp = None
executor = None
controller = None
cmd_manager = findCommand('netCommand')

#================ ON CLICK ================
def OnButtonClick():
    #---------------- ROBOT -----------------
    global executor, controller, comp
    if app.TeachContext != None and \
            app.TeachContext.ActiveRobot != None:
        comp = app.TeachContext.ActiveRobot
        controllers = comp.getBehavioursByType('rSimRobotController')
        executors = comp.getBehavioursByType('rRobotExecutor')
        if len(controllers):
            controller = controllers[0]
        if len(executors):
            executor = executors[0]
            
    if comp == None or executor == None or controller == None:
        print 'Please select a robot.'
        return

    #---------------- PROCESS HANDLER -----------------
    process_handler = comp.getBehaviour('TestProcessHandler')

    if process_handler != None:
        if process_handler.Script != GET_PROCESS_HANDLER_SCRIPT() :
            process_handler.Process = 'Test'
            process_handler.Script = GET_PROCESS_HANDLER_SCRIPT()
            print 'Updated "TestProcessHandler" behavior.'

    if process_handler == None:
        process_handler = comp.createBehaviour('rPythonProcessHandler', 'TestProcessHandler')
        process_handler.Process = 'Test'
        process_handler.Script = GET_PROCESS_HANDLER_SCRIPT()
        print 'Created "TestProcessHandler" behavior.'
    
    # ---------------- CREATE STATEMENT -------------------
    target = controller.createTarget()
    stat = executor.Program.MainRoutine.addStatement(VC_STATEMENT_PROCESS)
    stat.Process = process_handler
    pos = stat.createPosition("PTEST")
    stat.Base = target.BaseName
    stat.Tool = target.ToolName
    pos.PositionInReference = target.Target

#================ PROCESS HANDLER SCRIPT ================
def GET_PROCESS_HANDLER_SCRIPT():
    return """
from vcRslProcessHandler import *
from vcBehaviour import *
import vcMatrix
app = getApplication()
comp = getComponent()

#---------------- SETUP NEW STATEMENT -----------------
def OnStatementAdd(stat):
    pass

#---------------- UNSETUP STATEMENT -----------------
def OnStatementRemove(stat):
    pass

#---------------- STATEMENT EXECUTION -----------------
def OnStatementExecute(executor, stat):
    controller = executor.Controller
    controller.clearTargets()
    target = controller.createTarget()
    target.JointTurnMode = VC_MOTIONTARGET_TURN_NEAREST
    target.TargetMode = VC_MOTIONTARGET_TM_NORMAL
    target.MotionType = VC_MOTIONTARGET_MT_LINEAR
    if stat.Base == None:
        target.BaseName = ""
    else:
        target.BaseName = stat.Base.Name
    if stat.Tool == None:
        target.ToolName = ""
    else:
        target.ToolName = stat.Tool.Name
        
    positions = stat.Positions
    if len(positions) > 0:
        target.Target = positions[0].PositionInReference
    print "Testing, testing..."
    controller.moveTo(target)
"""

#---------------- INIT -----------------
addState(OnButtonClick)
