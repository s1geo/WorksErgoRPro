##template for add-on that can have contextual tab group, ribbon tab, and ribbon group

from vcApplication import *

def OnStart():
  cmduri = getApplicationPath() + "ShowContextualRibbonTab.py" 
  cmd = loadCommand("ShowContextualRibbonTab",cmduri)
  
  cmduri2 = getApplicationPath() + "printHelloLocalized.py" 
  cmd = loadCommand("printHelloLocalized",cmduri2)
  
  iconPath = getCommandPath() + "Hello.svg"
  localize = findCommand("netCommand")
  
  localize.execute("SetLocalizationCommand", "English", "Python", "printHelloLocalized", "Icon", iconPath)
  localize.execute("SetLocalizationCommand", "English", "Python", "NewRibbonGroup", "Icon", iconPath)
    
  
  #Step 1: First add Ribbon Contextual tab group. Id is the id of the group which Ribbon tab created in step 2 is going to associate.  
  addMenuItem(UxSite = 'pyContextTabGroup',UxName = "PythonExtraContextTab", Index = -1, Id = "pyContextTabGroup",Parent="gmAction",ControlType="ContextualTabGroup",BaseBackColor="#ff1985") #ssisss
  #Step 2: Add Ribbon Tab and associated it with Contextual ribbon group.The Parent attribute is to set the Contextual tab group. Id of Ribbon tab is the id it is used to be identified.
  addMenuItem(UxSite = "pyContextTabGroup/TabHeader", UxName="1st Tab", Index = -1, Id = "TabHeader",Parent="pyContextTabGroup", ControlType="RibbonTab")
  # now you can add ribbon items in this
  addMenuItem('pyContextTabGroup/TabHeader/NewRibbonGroup', "R Group" , -1, "printHelloLocalized" , "","","","")
  
  