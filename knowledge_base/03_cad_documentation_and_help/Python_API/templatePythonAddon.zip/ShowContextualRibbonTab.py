#example on how to show/hide contextual tab group

from vcCommand import * 

app = getApplication()
cmd = getCommand()

def ShowOrHideCustomRibbonTab():
  if app.CurrentContext.Id == "Drawing":
    app.setContextualTabGroup("pyContextTabGroup",False)
    print "Your custom pyContextTabGroup is hidden in " + app.CurrentContext.Id + "context"
  elif app.CurrentContext.Id == "Teach":
    app.setContextualTabGroup("pyContextTabGroup",True)
    print "Your custom pyContextTabGroup is shown in " + app.CurrentContext.Id + "context"
  else:
    app.setContextualTabGroup("pyContextTabGroup",True)
    print "Your custom pyContextTabGroup is shown in " + app.CurrentContext.Id + "context"
  

app.OnContextChanged = ShowOrHideCustomRibbonTab

