from vcApplication import *

def OnAppInitialized():
    cmduri = getApplicationPath() + "pick.py"
    cmd = loadCommand("snapPick",cmduri)
    
    addMenuItem("VcTabHome/Pick", "Pick", -1, "snapPick")