#command file for Python add-on
from vcCommand import *

def testSet(cmd):
  if cmd.TargetAvailable:
    print "##------------SET--------------"
    print cmd.TargetGeoset

    p = cmd.TargetPosition
    print p.X, p.Y, p.Z
    
    #continue if target was selected
    setNextState(pick)
  else:
    #stop if no target selected
    print "Command exit"
    setNextState(None)

def pick():
  print "pick!"
  cmd.execute()

app = getApplication()
cmd = app.findCommand("interactiveSnap")
cmd.SnapOnCurve = True
cmd.SnapOnEdge = True
cmd.SnapOnSurface = True
cmd.OnTargetSet = testSet

addState(pick)
