from vcCommand import *

cmd = getCommand()
prop1 = cmd.createProperty(VC_STRING,"ExampleProperty",VC_PROPERTY_STEP)
prop1.StepValues = ["Red","Green","Blue"]
prop1.Value = prop1.StepValues[0]

def firstState():
    executeInActionPanel()
    
cmd.addState(firstState)