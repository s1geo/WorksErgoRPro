from vcApplication import *

def OnAppInitialized():
    cmduri = getApplicationPath() + "cmdExample.py"
    cmd = loadCommand("example",cmduri)
    addMenuItem("VcTabHome/rMyGroup", "", -1, "example") 